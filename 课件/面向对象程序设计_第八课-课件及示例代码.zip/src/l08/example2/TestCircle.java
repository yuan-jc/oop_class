package l08.example2;

import java.util.Date;

public class TestCircle {
	/** Main method */
	public static void main(String[] args) {

		Circle myCircle = new Circle(5.0, "my circle");
		System.out.println("���ƣ�" + myCircle.getCircleName());
		System.out.println("�뾶��" + myCircle.getRadius());
		System.out.println("�����" + myCircle.getArea());
		System.out.println("���󴴽�ʱ�䣺" + myCircle.getDateCreated());
		
		String newName = myCircle.getCircleName();
		newName = "your circle";
		myCircle.getDateCreated().setYear(100);
		
		System.out.println("------------------------------------");	
		System.out.println("���ƣ�" + myCircle.getCircleName());
		System.out.println("�뾶��" + myCircle.getRadius());
		System.out.println("�����" + myCircle.getArea());
		System.out.println("���󴴽�ʱ�䣺" + myCircle.getDateCreated());
	}
}
