package l04.example5;

public class TestExample {

  public static void main(String[] args) {
	  
	  Example e = new Example();
	  
	  int i = 2;
	  int j = 5;
	  
	  e.calculate(i, j);
	  
  }
}
