package l04.example5;

public class Example {
			
	public void calculate(int num1, int num2){
		System.out.println("���� calculate(int num1, int num2)");
		
		int maxResult = max(num1, num2);
		
		System.out.println("calculate(int num1, int num2)��������...");
		
		int sumResult = sum(num1, num2);
		
		System.out.println("calculate(int num1, int num2)��������...");
		
		System.out.println("maxResult = " + maxResult);
		System.out.println("sumResult = " + sumResult);
		
//		System.out.println("maxResult = " + max(num1, num2));
//		System.out.println("sumResult = " + sum(num1, num2));
		
		System.out.println("�뿪 calculate(int num1, int num2)");
	}
	
	public int max(int num1, int num2){
		System.out.println("------���� max(int num1, int num2)");
		
		int result;
		
		if(num1 > num2){
			result = num1;
		} else {
			result = num2;
		}
		
		System.out.println("------�뿪 max(int num1, int num2)");
		
		return result;
	}
	
	public int sum(int num1, int num2){
		System.out.println("------���� sum(int num1, int num2)");
		
		int result = num1 + num2;
		
		System.out.println("------�뿪 sum(int num1, int num2)");
		
		return result;
	}	
}
