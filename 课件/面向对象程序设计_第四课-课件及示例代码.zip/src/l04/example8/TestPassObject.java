package l04.example8;

public class TestPassObject {

  public static void main(String[] args) {
	  
	  Circle myCircle = new Circle(2.0);
	  CirclePrinter printer = new CirclePrinter();
	  int n = 5;
	  
	  System.out.println("myCircle�İ뾶�ǣ�" + myCircle.radius);
	  System.out.println("n��ֵΪ��" + n);

	  System.out.println("------------------");
	  
	  //Circle myCircleCopy = new Circle();
	  //myCircleCopy.radius = myCircle.radius;
	  
	  printer.print(myCircle, n);
	  
	  System.out.println("------------------");
	  
	  System.out.println("myCircle�İ뾶�ǣ�" + myCircle.radius);
	  System.out.println("n��ֵΪ��" + n);
  }
}
