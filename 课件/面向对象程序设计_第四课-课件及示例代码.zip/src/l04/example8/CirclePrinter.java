package l04.example8;

class CirclePrinter {
	
	CirclePrinter() {
	}

	public void print(Circle c, int times){
		System.out.println("�뾶 \t\t���");
		
		while (times > 0){
			System.out.println(c.radius + "\t\t" + c.getArea());
			c.radius ++;
			times --;
		}
	}
}