package l04.example12;

public class ClassB {
	public static void main(String[] args) {
		for (int i = 0; i < args.length; i++)
			System.out.println(args[i]);
	}
}
