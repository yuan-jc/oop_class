package l04.example12;

public class ClassA {
	public static void main(String[] args) {
		String[] strings = { "New York", "Boston", "Atlanta" };
		ClassB.main(strings);
	}
}
