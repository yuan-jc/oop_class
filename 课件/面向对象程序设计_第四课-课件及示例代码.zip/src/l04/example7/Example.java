package l04.example7;

public class Example {
		
	public Example(){
		
	}
	
	public void nPrintln(String message, int n){
		for (int i = 0; i < n; i++){
			System.out.println(message);
		}
	}
	
	public void printMax(double num1, double num2) {
		if (num1 > num2)
			System.out.println(num1);
		else
			System.out.println(num2);
	}
}
