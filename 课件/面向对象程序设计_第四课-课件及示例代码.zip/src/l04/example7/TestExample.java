package l04.example7;

public class TestExample {

  public static void main(String[] args) {
	  
	  Example e = new Example();
	  
	  String message = "Hello!";
	  int n = 2;
	  
	  e.nPrintln(message, n);
	  //e.nPrintln(n, message);
	  
	  int a = 1;
	  int b = 2;
	  e.printMax(a, b);
	  //e.printMax("1", "2");
	
  }
}
