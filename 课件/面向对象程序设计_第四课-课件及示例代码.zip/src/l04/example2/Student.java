package l04.example2;

public class Student {
	
	String name;
	int age;
	boolean isComputerScience;
	char gender;
	
	Student(){
		//this("��", 0, false, 'x');
		
		name = "��";
		age = 0;
		isComputerScience = false;
		gender = 'x';
	}
	
	Student(String initialName, int initialAge, boolean initialMajor, char initialGender){
		name = initialName;
		age = initialAge;
		isComputerScience = initialMajor;
		gender = initialGender;
	}
	
	Student(char initialGender, String initialName, int initialAge, boolean initialMajor){
		this.name = initialName;
		this.age = initialAge;
		this.isComputerScience = initialMajor;
		this.gender = initialGender;
	}		
}
