package l04.example2;

public class TestStudent {

  public static void main(String[] args) {
	  
	  Student s1 = new Student();
	  
	  System.out.println("name:" + s1.name);
	  System.out.println("age:" + s1.age);
	  System.out.println("isComputerScience:" + s1.isComputerScience);
	  System.out.println("gender:" + s1.gender);
	  
	  System.out.println("------------------------------");
	  
	  Student s2 = new Student("����", 20, true, 'm');
	  
	  System.out.println("name:" + s2.name);
	  System.out.println("age:" + s2.age);
	  System.out.println("isComputerScience:" + s2.isComputerScience);
	  System.out.println("gender:" + s2.gender);
  }

}
