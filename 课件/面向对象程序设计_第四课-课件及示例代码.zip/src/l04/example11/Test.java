package l04.example11;

public class Test {

	static {
		System.out.println("i am not in main()");
	}
	
	public static void main(String[] args) {
		System.out.println("main() in");

		System.out.println("main() out");
	}
	
}