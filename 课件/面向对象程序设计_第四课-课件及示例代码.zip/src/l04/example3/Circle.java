package l04.example3;

class Circle {
	double radius = 1.0;
	final double PI = 3.14159;
			
	/** Construct a circle with radius 1 */
	Circle() {
		
	}

	/** Construct a circle with a specified radius */
	Circle(double newRadius) {
		radius = newRadius;
	}

	/** Return the area of this circle */
	double getArea() {
		return radius * radius * PI;
	}

}