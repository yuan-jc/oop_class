package l04.example3;

public class TestCircle {
  /** Main method */
  public static void main(String[] args) {

	  Circle c1 = new Circle(5.0);
	  Circle c2 = new Circle(9.0);
	  
	  System.out.println("c1���Ϊ��" + c1.getArea());
	  System.out.println("c2���Ϊ��" + c2.getArea());

	  System.out.println("---------------------------------------");
	  System.out.println("c1 = c2");
	  c1 = c2;
	  
	  System.out.println("c1���Ϊ��" + c1.getArea());
	  System.out.println("c2���Ϊ��" + c2.getArea());
	  
	  System.out.println("---------------------------------------");
	  System.out.println("c1.radius = 1.0");
	  c1.radius = 1.0;
	  
	  System.out.println("c1���Ϊ��" + c1.getArea());
	  System.out.println("c2���Ϊ��" + c2.getArea());
	  
	  System.out.println("---------------------------------------");
	  System.out.println("c2.radius = 2.0");
	  c2.radius = 2.0;
	  
	  System.out.println("c1���Ϊ��" + c1.getArea());
	  System.out.println("c2���Ϊ��" + c2.getArea());
  }
}
