package l04.example3;

import java.util.LinkedList;
import java.util.List;

/*
 * -Xmx30m
 */
public class TestOutOfMemory {
	/** Main method */
	public static void main(String[] args) {
		
		List l = new LinkedList();
		Circle c;
		int x = 1;
		while (true) {
			c = new Circle(5.0);
			l.add(c);
			System.out.println(x++);
		}		
	}
}
