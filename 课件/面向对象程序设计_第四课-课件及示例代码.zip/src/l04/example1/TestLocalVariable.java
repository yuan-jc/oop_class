package l04.example1;

public class TestLocalVariable {

	public static void main(String[] args) {

		int x;
		int y;

		System.out.println("x=" + x);
		System.out.println("y=" + y);

	}
}
