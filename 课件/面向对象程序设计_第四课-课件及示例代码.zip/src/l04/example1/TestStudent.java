package l04.example1;

public class TestStudent {

  public static void main(String[] args) {
	  
	  Student student = new Student();
	  
	  System.out.println("name:" + student.name);
	  System.out.println("age:" + student.age);
	  System.out.println("isComputerScience:" + student.isComputerScience);
	  System.out.println("gender:" + student.gender);
  }

}
