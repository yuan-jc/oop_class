package l04.example1;

public class Student {

	String name;
	int age;
	boolean isComputerScience;
	char gender;

	Student(String name, int age, boolean isComputerScience, char gender) {
		// initialize...
	}

}
