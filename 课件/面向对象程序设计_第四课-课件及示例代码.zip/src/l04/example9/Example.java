package l04.example9;

public class Example {

	public Example() {
	}

	public int max(int num1, int num2) {
		System.out.println("���� max(int num1, int num2)");
		if (num1 > num2)
			return num1;
		else
			return num2;
	}

	public double max(double num1, double num2) {
		System.out.println("���� max(double num1, double num2)");
		if (num1 > num2)
			return num1;
		else
			return num2;
	}

	public double max(double num1, double num2, double num3) {
		System.out.println("���� max(double num1, double num2, double num3)");
		return max(max(num1, num2), num3);
	}
	
	public double max(double num1, int num2) {
		System.out.println("max(double num1, int num2)");
		if (num1 > num2)
			return num1;
		else
			return num2;
	}
	
	public double max(int num1, double num2) {
		System.out.println("max(int num1, double num2)");
		if (num1 > num2)
			return num1;
		else
			return num2;
	}
}
