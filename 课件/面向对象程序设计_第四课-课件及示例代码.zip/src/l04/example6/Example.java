package l04.example6;

public class Example {

	public Example() {

	}

	public int sign(int n) {
		if (n > 0) {
			return 1;
		} else if (n == 0) {
			return 0;
		} else if (n < 0) {
			return -1;
		}
	}
}
