package l04.example4;

public class Example {
		
	public Example(){
		
	}
	
	public void doIt(){
		System.out.println("���� doIt()");
		
		helpMe();
		
		System.out.println("�뿪 doIt()");
	}
	
	public void helpMe(){
		System.out.println("���� helpMe()");
		
		System.out.println("�뿪 helpMe()");
	}
	
}
