package l04.example4;

public class TestExample {

  public static void main(String[] args) {
	  
	  Example e = new Example();
	  
	  e.doIt();
	  
  }
}
