package l10.example8;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JButton;

public class Main {

	public static void main(String[] args) {
		/**
		 * �б�����
		 */
		List<Integer> list = new ArrayList<>();
		for (int j = 0; j <= 10; j++) {
			list.add(j);
		}
		
		// Java 8֮ǰ
		for(int item: list){
			  System.out.println(item);
		}

		// Java 8��ʽ
		list.forEach(a -> System.out.println(a));
		
		list.forEach(System.err::println);
		
		/**
		 * ���߳�
		 */
		// Java 8֮ǰ��
		new Thread(new Runnable() {
		    @Override
		    public void run() {
		    	System.out.println("Before Java8, too much code for too little to do");
		    }
		}).start();
		
		//Java 8��ʽ
		new Thread(() -> System.out.println("In Java8, Lambda expression rocks !!")).start();
		
		/**
		 * �¼�����
		 */
		// Java 8֮ǰ
		JButton show =  new JButton("Show");
		show.addActionListener(new ActionListener() {
		    @Override
		    public void actionPerformed(ActionEvent e) {
		    	System.out.println("Event handling without lambda expression is boring");
		    }
		});
		
		// Java 8��ʽ��
		show.addActionListener(e -> {
		    System.out.println("Light, Camera, Action !! Lambda expressions Rocks");
		});
	}
}
